# ABCinema
ABCinema Web App


files that are actually pages so far:

1) login.php
2) sign_up.php
3) profile.php
4) display_movie_info.php
5) movies.php
6) checkout.php


other php pages not mentioned here are for functional usage only, that is for data manipulation / sending emails (forget password feature)

additionally, reset_password.php is a page but that is only sent via email for access