<?php
$servername = "localhost";  // or your server's IP address
$username = "root"; // replace with your MySQL username
$password = ""; // replace with your MySQL password
$database = "abcinema_db"; // replace with your database name
//$database = "abcinema"; // replace with your second database name

$conn = new mysqli($servername, $username, $password, $database);
